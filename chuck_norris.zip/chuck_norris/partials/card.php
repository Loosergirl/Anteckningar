  <section class="container m-5">
    <div class="row" id="content">
    <div class="card card-inverse">
      <img class="card-img img-responsive" src="img/chuck_norris.jpg" alt="Card image">
        <div class="card-img-overlay">
          <p class="card-text text-center font-italic font-weight-bold" id="store_text"> 
            <?= $data['value'] ?>
          </p>
        </div>
      </div>
      <button type="button" class="button btn-link font-weight-bold" value="Refresh Page" onClick="window.location.reload()">One more joke</button>    
    </div>
  </section>