<!--För att hämta ut headern -->
<?php include 'partials/header.php'; ?>


  <header class="container-fluid text-center m-5">
    <h1 class="text-muted">Chuck Norris jokes</h1>
  </header>

<!--För att hämta ut curl-filen som hämtar datan från APIt -->
<?php include 'functions/curl.php' ?>
<?php include 'partials/card.php' ?>
    

  <?php include 'partials/footer.php'; ?>


