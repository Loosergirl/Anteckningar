/*let nextJoke = document.getElementbyId("next_joke").addEventListener("onclick", function(){
  document.getElementbyId("store_text").innerHTML = null;
})
nextJoke();*/