<?php

function curl_it(){

  //1. Initialize
  //starta request  (create a new cURL resource)
  //ch stands for curl handle
  $ch = curl_init();

  //To solve certificate-issue
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  //2. Set options
  //set URL and other appropriate options
  //This means return instead of output directly
  //The url is our value of this option that we are setting
  curl_setopt($ch, CURLOPT_URL, 'https://api.chucknorris.io/jokes/random');
  //We only want to return transfer first to be able to process the data in php. The data is then stored in the data below.
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

  //3. Execute the request and fetch the response. Check for errors
  // Här är vår data som returneras  (grab URL and pass it to the browser)
  $data = curl_exec($ch);

  //Check for error-status
  if($data === false){
    echo "cURL Error" . curl_error($ch);
  }

  //avsluta request  (close cURL resource, and free up system resources)
  curl_close($ch);

  //Takes a JSON encoded string and converts it into a PHP variable
  return json_decode($data, true);

}

$data = curl_it();


 /*$ch = curl_init(); //initiate cURL request
  curl_setopt($ch, CURLOPT_URL,'https://api.chucknorris.io/jokes/random'); //set url
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //return content
  $data = curl_exec($ch); //execute the request
  curl_close($ch); //close the request
  echo $data; //return the data

  http://randomword.setgetgo.com/get.php