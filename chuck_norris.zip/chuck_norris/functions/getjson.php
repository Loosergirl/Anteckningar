<?php
 
function get_file(){ 
  $data = file_get_contents("http://randomword.setgetgo.com/get.php");
  	echo $data;

}

get_file();